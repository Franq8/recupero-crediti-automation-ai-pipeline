# Discord v1 post-run report

- Practice ID: P-20260313-2I15HU0UNJ
- Template: doc-generator-sample-template.docx
- Table: doc-generator-sample.csv
- Generated documents: 2/2
- Rows with warnings: 0
- Rows with errors: 0

## Phase 1 — first table / prepare
- Mode: DETERMINISTIC_TABLE_FIRST
- Outcome: match
- Special placeholders detected: yes
- Next action: enrich-final-table
- Warnings: none

## Phase 2 — final table / enrich
- Executed: yes
- Derived keys: 0
- Generated keys: 0
- Warnings: none

## Phase 3 — final generation
- Row 1: generated -> precetto_P-20260313-2I15HU0UNJ_row1_2026-03-13T21-50-01-661Z.docx; missingFields=0
- Row 2: generated -> precetto_P-20260313-2I15HU0UNJ_row2_2026-03-13T21-50-01-667Z.docx; missingFields=0

## Notes
- Discord v1 auto-continues the standard web flow without intermediate confirmations.
- Generation is attempted for every row; warnings do not block output.
- Real technical errors remain blocking only for the affected row or invalid input contract.